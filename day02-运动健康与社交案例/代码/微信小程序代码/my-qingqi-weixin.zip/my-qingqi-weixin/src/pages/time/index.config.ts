export default {
  navigationBarTitleText: "轻骑",
  navigationBarBackgroundColor: "#fcd700",
  navigationStyle: "custom", //隐藏系统自带导航
};
