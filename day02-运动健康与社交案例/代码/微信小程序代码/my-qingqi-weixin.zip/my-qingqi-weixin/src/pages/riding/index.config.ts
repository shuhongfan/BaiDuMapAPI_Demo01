export default {
  navigationBarTitleText: "",
  navigationStyle: "custom", //隐藏系统自带导航
};
