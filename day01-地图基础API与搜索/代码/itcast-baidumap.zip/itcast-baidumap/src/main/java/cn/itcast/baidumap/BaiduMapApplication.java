package cn.itcast.baidumap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BaiduMapApplication {

    public static void main(String[] args) {
        SpringApplication.run(BaiduMapApplication.class, args);
    }
}
